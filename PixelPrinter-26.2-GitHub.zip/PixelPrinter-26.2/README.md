# PixelPrinter 26.2

Modernized port of the uploaded PixelPrinter 1.0.48 source for Paper 26.2 / Java 25.

## Build

```bash
mvn -B clean package
```

Output: `target/PixelPrinter-26.2.1.jar`

## Requirements
- Minecraft Java 26.2
- Paper 26.2
- Java 25

## Notes
- Legacy raw block-data APIs were replaced with modern BlockData where required.
- Runtime self-updating is disabled; use releases/GitHub Actions instead.
- Original image/GIF/map/skin functionality is retained as far as the old source/API permits.
- Large renders still depend on the original renderer logic; test large images on a backup world first.

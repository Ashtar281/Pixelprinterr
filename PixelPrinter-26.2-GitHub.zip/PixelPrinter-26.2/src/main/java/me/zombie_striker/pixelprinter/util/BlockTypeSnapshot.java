package me.zombie_striker.pixelprinter.util;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;

import java.util.HashMap;
import java.util.Map;

/**
 * Modern Paper-safe undo snapshot using BlockData instead of removed raw-data APIs.
 */
public class BlockTypeSnapshot {
    public HashMap<Location, String> originalBlockState = new HashMap<>();

    public BlockTypeSnapshot(Location start, Location stop) {
        World world = start.getWorld();
        if (world == null) return;
        for (int x = Math.min(start.getBlockX(), stop.getBlockX()); x <= Math.max(start.getBlockX(), stop.getBlockX()); x++) {
            for (int y = Math.min(start.getBlockY(), stop.getBlockY()); y <= Math.max(start.getBlockY(), stop.getBlockY()); y++) {
                for (int z = Math.min(start.getBlockZ(), stop.getBlockZ()); z <= Math.max(start.getBlockZ(), stop.getBlockZ()); z++) {
                    Block b = world.getBlockAt(x, y, z);
                    originalBlockState.put(b.getLocation(), b.getBlockData().getAsString());
                }
            }
        }
    }

    public void undo() {
        HashMap<Location, String> newOnes = new HashMap<>();
        for (Map.Entry<Location, String> e : originalBlockState.entrySet()) {
            Block block = e.getKey().getBlock();
            String current = block.getBlockData().getAsString();
            if (!current.equals(e.getValue())) {
                newOnes.put(e.getKey(), current);
                try {
                    BlockData data = org.bukkit.Bukkit.createBlockData(e.getValue());
                    block.setBlockData(data, true);
                } catch (IllegalArgumentException ignored) {
                    // Keep undo resilient if a legacy block state is no longer valid.
                }
            }
        }
        this.originalBlockState = newOnes;
    }
}

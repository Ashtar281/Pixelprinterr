package me.zombie_striker.pixelprinter.util;

/** Modern Paper compatibility helper. Legacy NMS reflection is intentionally unsupported. */
public final class ReflectionUtil {
    private ReflectionUtil() {}

    public static boolean isVersionHigherThan(int major, int minor) {
        return true;
    }

    public static Class<?> getCraftbukkitClass(String name) {
        try { return Class.forName(name); } catch (Throwable ignored) { return null; }
    }

    public static Class<?> getCraftbukkitClass(String name, String version) {
        return getCraftbukkitClass(name);
    }

    public static Object invokeMethod(Object object, String method, Object... args) {
        if (object == null) return null;
        try {
            Class<?>[] types = new Class<?>[args == null ? 0 : args.length];
            for (int i = 0; i < types.length; i++) types[i] = args[i] == null ? Object.class : args[i].getClass();
            java.lang.reflect.Method target = null;
            for (java.lang.reflect.Method m : object.getClass().getMethods()) {
                if (m.getName().equals(method) && m.getParameterCount() == types.length) { target = m; break; }
            }
            if (target == null) return null;
            return target.invoke(object, args == null ? new Object[0] : args);
        } catch (Throwable ignored) { return null; }
    }
}
